setwd("C:\\Users\\SANDARU\\Desktop\\IT24101024")
branch_data<-read.table("Exercise.txt", header = TRUE,sep = ",")
fix(branch_data)
str(branch_data)
attach(branch_data)

##(3) Obtain boxplot for sales and interpret the shape of the sales distribution
boxplot(branch_data$Sales_X1, main = "Sales - Boxplot", outline=TRUE, outpch=8, col="lightblue",horizontal = TRUE )

##(4) Calculate the five number summary and IQR for advertising variable
summary(branch_data$Advertising_X2)

IQR(branch_data$Advertising_X2)

##(5) find the outliers in a numeric vector and check for outliers in years variables

##Function to check existence of outliers of a data set
get.outliers <- function(z){
  q1 <- quantile(z)[2]
  q3 <- quantile(z)[4]
  iqr <- q3 - q1
  
  ub <- q3 + 1.5 * iqr
  lb <- q1 - 1.5 * iqr
  print(paste("Upper Bound = ", ub))
  print(paste("Lower Bound = ", lb))
  print(paste("Outliers: ", paste(sort(z[z<lb | z >ub]), collapse = ",")))
}

##Checking the outliers of years variable
get.outliers(branch_data$Years_X3)
