setwd("C:\\Users\\it24101024\\Desktop\\IT24101024")
getwd()

##01. Import the dataset
Delivery_Times<-read.table("Exercise - Lab 05.txt",header=TRUE,sep=",") 

fix(Delivery_Times)
names(Delivery_Times)<-c("X1")
attach(Delivery_Times)

##02. Histogram for deliver times
histogram<-hist(X1,main = "Histogram for Delivery Times",
                xlab = "Delivery Times",
                breaks = seq(20, 70,length=10),
                right = FALSE,
                col = "lightblue")

##04.A cumulative frequency polygon (ogive) for the data in a separate plot
breaks <- round(histogram$breaks)
breaks
freq<-histogram$counts
freq


cum.freq <-cumsum(freq)
cum.freq

new<-c()
for(i in 1:length(breaks)){
  if(i==1){
    new[i]=0
  }else{
    new[i]=cum.freq[i-1]
  }
}

plot(breaks, new, type='o',main="Cumulative frequency polygon for Delivery Time", xlab="Delivery Time(minutes)", ylab="Frequency", ylim= c(0,max(cum.freq)),col="darkblue",pch=16)
